<?php
namespace Pecee\Controllers;
class HomeController{
    public function index(){
        echo "hello index";
    }
}