<?php
session_status();
get_header();
if(isset($_SESSION['name'])){
    echo "Halaman Dashboard Admin";
}