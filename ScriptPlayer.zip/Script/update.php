<?php
include "config.php";
global $conn;
$query = "ALTER TABLE links ADD subtitle VARCHAR( 5000 ) after file";
if($conn->query($query) == true){
    echo "success update database";
    unlink('update.php');
} else {
    echo "check file config.php";
};
