<?php
error_reporting(0);
ini_set('display_errors','off');

$servername = "localhost";
$username = "gplayer"; //Username Data Base Yang Di Buat
$password = "gadmin"; //Password Data Base Yang Di Buat
$database = "gplayer"; //Nama Data Base Yang Kalian Buat

$vastads1 = ""; //TAG VAST ADS YANG AKAN DI TAMPILKAN SEBELUM VIDEO DIMULAI #UbahBagianIni
$vastads2 = ""; //TAG VAST ADS YANG AKAN DI TAMPILKAN DI TENGAH-TENGAH VIDEO #UbahBagianIni
$vastads3 = ""; //TAG VAST ADS YANG AKAN DI TAMPILKAN DI AKHIR VIDEO #UbahBagianIni

// Create connection
$conn = new mysqli($servername, $username, $password, $database);
global $conn;
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
    $query = "SELECT * FROM settings";
    $rs = $conn->query($query);
    $rows = array();
    while($r = $rs->fetch_assoc()) {
        $rows[$r['westheme_key']] = $r['westheme_value'];
    }
    $json = json_encode($rows);
    $settings = json_decode($json);
}
